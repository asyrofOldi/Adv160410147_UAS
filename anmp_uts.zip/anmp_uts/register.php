<?php
error_reporting(E_ERROR | E_PARSE);

$host = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "anmp_uts";

// Membuat koneksi ke database
$conn = new mysqli($host, $username, $password, $dbname);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Menerima data dari request POST
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password']; 

// Menggunakan password_hash untuk hashing password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Menyiapkan SQL statement untuk menyisipkan data
$query = "INSERT INTO users (firstName, lastName, username, email, password) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    exit;
}

// Bind parameter ke statement
$bind = $stmt->bind_param("sssss", $firstName, $lastName, $username, $email, $hashedPassword);
if (!$bind) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
    exit;
}

// Menjalankan statement
if ($stmt->execute()) {
    echo json_encode(['message' => 'User registered successfully']);
} else {
    echo json_encode(['message' => 'User registration failed', 'error' => $stmt->error]);
}

// Menutup statement dan koneksi
$stmt->close();
$conn->close();
?>
