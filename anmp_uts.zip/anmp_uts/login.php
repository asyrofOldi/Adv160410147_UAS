<?php
header('Content-Type: application/json');


$host = "localhost";
$dbname = "anmp_uts";
$user = "root";
$pass = "";

// Membuat koneksi ke database
$conn = new mysqli($host, $user, $pass, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Ambil dan sanitasi input
$username = $conn->real_escape_string($_POST['username']);
$password = $_POST['password'];

if (empty($username) || empty($password)) {
    echo json_encode(['status' => 'error', 'message' => 'Username and password are required']);
    exit;
}

// Query ke database untuk mendapatkan data user
$query = $conn->prepare("SELECT username, FirstName, LastName, password FROM users WHERE username = ?");
$query->bind_param("s", $username);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Verifikasi password
    if (password_verify($password, $user['password'])) {
        // Prepare data to send back
        $userData = [
            'username' => $user['username'],
            'FirstName' => $user['FirstName'],
            'LastName' => $user['LastName'],
            'Password' => $user['password']
        ];
        echo json_encode(['status' => 'success', 'message' => 'Login successful', 'userData' => $userData]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid password']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Username not found']);
}

$query->close();
$conn->close();
?>