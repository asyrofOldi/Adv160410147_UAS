<?php

// Mendapatkan nilai id dari URL
$id = $_GET['gameID'];

// Menampilkan data pahlawan yang sesuai dengan id
$games_json = '[
    {
        "gameID": 1,
        "title": "Elder Scrolls V: Skyrim`s 10th Anniversary",
        "genre": "RPG",
        "developer": "Bethesda",
        "description":"The Elder Scrolls V: Skyrim`s 10th Anniversary edition celebrates a decade of this iconic open-world RPG. This special version includes the complete original game along with all previously released expansions and additional content. Players can explore the vast, detailed world of Skyrim, encountering a rich tapestry of history, culture, and relentless danger as they quest to defeat a dragon prophesied to destroy the world. Enhanced graphics and new features, like fishing, further enrich the immersive experience, making it a must-play for both newcomers and returning fans.",
        "imageURL": "https://www.liveabout.com/thmb/sdXHWzo7STs50CbbKqAtu6wDUxo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Elder-Scrolls-V-Skyrim-56a9c3893df78cf772aa569c.jpg",
        "publisher": "Bethesda",
        "releaseDate": "2011-11-11",
        "news": {
            "title": "Skyrim Anniversary Edition Brings New Quests",
            "author": "GamerGuy123",
            "imageURL": "https://www.liveabout.com/thmb/sdXHWzo7STs50CbbKqAtu6wDUxo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Elder-Scrolls-V-Skyrim-56a9c3893df78cf772aa569c.jpg",
            "pages": [
                "The Elder Scrolls V: Skyrim`s 10th Anniversary edition celebrates a decade of this iconic open-world RPG. This special version includes the complete original game along with all previously released expansions and additional content. Players can explore the vast, detailed world of Skyrim, encountering a rich tapestry of history, culture, and relentless danger as they quest to defeat a dragon prophesied to destroy the world. Enhanced graphics and new features, like fishing, further enrich the immersive experience, making it a must-play for both newcomers and returning fans.",
                "The Elder Scrolls V: Skyrim has celebrated its 10th anniversary with a special edition that includes new quests and content.",
                "Fans of the game can look forward to exploring new dungeons and encountering new NPCs in the game.",
                "The anniversary edition also includes quality-of-life improvements and bug fixes."
            ]
        }
    },
    {
        "gameID": 2,
        "title": "The Witcher 3: Wild Hunt`s Expansion Success",
        "genre": "RPG",
        "developer": "CD Projekt Red",
        "description": "The Witcher 3: Wild Hunt`s expansions, Hearts of Stone and Blood and Wine, enhance the acclaimed RPG with new stories and expansive areas. Hearts of Stone features a gripping plot involving the mysterious Gaunter O`Dimm, while Blood and Wine introduces the colorful realm of Toussaint. Both are celebrated for their deep narratives and impactful choices, exemplifying top-tier downloadable content in gaming.",
        "imageURL": "https://gamingbolt.com/wp-content/uploads/2015/08/witcher-3-hearts-of-stone.jpg",
        "publisher": "CD Projekt",
        "releaseDate": "2015-05-19",
        "news": {
            "title": "The Witcher 3 Expansions Receive Praise",
            "author": "RiviaFan",
            "imageURL": "https://gamingbolt.com/wp-content/uploads/2015/08/witcher-3-hearts-of-stone.jpg",
            "pages": [
                "The Witcher 3: Wild Hunt`s expansions, Hearts of Stone and Blood and Wine, enhance the acclaimed RPG with new stories and expansive areas. Hearts of Stone features a gripping plot involving the mysterious Gaunter O`Dimm, while Blood and Wine introduces the colorful realm of Toussaint. Both are celebrated for their deep narratives and impactful choices, exemplifying top-tier downloadable content in gaming.",
                "The Witcher 3: Wild Hunt has released two major expansions, adding significant content to the game.",
                "Both Hearts of Stone and Blood and Wine expansions offer new quests, areas, and stories, praised for their depth and quality.",
                "CD Projekt Red continues to set high standards for downloadable content in the industry."
            ]
        }
    },
    {
        "gameID": 3,
        "title": "Cyberpunk 2077: A Look Into The Future",
        "genre": "Action-RPG",
        "developer": "CD Projekt Red",
        "description":"Cyberpunk 2077: A Look Into The Future - Dive into a dystopian world of high-tech weaponry and cybernetic enhancements in Cyberpunk 2077. This open-world RPG set in the vibrant Night City offers deep narrative choices and cutting-edge visuals, depicting a future where technology and humanity intersect in complex ways.",
        "imageURL": "https://cdn.mos.cms.futurecdn.net/BeyhFdCM2ugLQjX8vX7fuQ-1200-80.jpg",
        "publisher": "CD Projekt",
        "releaseDate": "2020-12-10",
        "news": {
            "title": "Cyberpunk 2077 Overcomes Launch Issues",
            "author": "NightCityExplorer",
            "imageURL": "https://cdn.mos.cms.futurecdn.net/BeyhFdCM2ugLQjX8vX7fuQ-1200-80.jpg",
            "pages": [
                "Cyberpunk 2077: A Look Into The Future - Dive into a dystopian world of high-tech weaponry and cybernetic enhancements in Cyberpunk 2077. This open-world RPG set in the vibrant Night City offers deep narrative choices and cutting-edge visuals, depicting a future where technology and humanity intersect in complex ways.",
                "After a rocky start, Cyberpunk 2077 has received numerous updates to address launch issues.",
                "The game now offers a more stable experience, with improvements to performance and gameplay.",
                "CD Projekt Red`s commitment to fixing Cyberpunk 2077 has been commendable, regaining trust from many players."
            ]
        }
    },
    {
        "gameID": 4,
        "title": "Red Dead Redemption 2: A Western Epic",
        "genre": "Action-Adventure",
        "developer": "Rockstar Games",
        "description":"Red Dead Redemption 2: A Western Epic - Experience the rugged beauty and lawless frontier of the late 1800s in Red Dead Redemption 2. This sprawling western adventure delivers a profound story of loyalty and survival, featuring vast landscapes, dynamic weather, and a detailed ecosystem.",
        "imageURL": "https://cdn.vox-cdn.com/thumbor/Er2eWbWLSmBwBhj39KWskM-8xi4=/0x0:1920x1080/1200x800/filters:focal(807x387:1113x693)/cdn.vox-cdn.com/uploads/chorus_image/image/51397987/red_dead_2_announcement.1476795730.jpg",
        "publisher": "Rockstar Games",
        "releaseDate": "2018-10-26",
        "news": {
            "title": "Red Dead Redemption 2`s Immersive World",
            "author": "CowboyJohn",
            "imageURL": "https://cdn.vox-cdn.com/thumbor/Er2eWbWLSmBwBhj39KWskM-8xi4=/0x0:1920x1080/1200x800/filters:focal(807x387:1113x693)/cdn.vox-cdn.com/uploads/chorus_image/image/51397987/red_dead_2_announcement.1476795730.jpg",
            "pages": [
                "Red Dead Redemption 2: A Western Epic - Experience the rugged beauty and lawless frontier of the late 1800s in Red Dead Redemption 2. This sprawling western adventure delivers a profound story of loyalty and survival, featuring vast landscapes, dynamic weather, and a detailed ecosystem.",
                "Red Dead Redemption 2 offers one of the most immersive open worlds in video game history.",
                "From breathtaking landscapes to intricate details in towns, the game sets a new bar for realism.",
                "Rockstar Games has created a living, breathing world that players can lose themselves in for hours on end."
            ]
        }
    },
    {
        "gameID": 5,
        "title": "Legend of Zelda: Breath of the Wild - A New Adventure",
        "genre": "Action-Adventure",
        "developer": "Nintendo",
        "description":"Legend of Zelda: Breath of the Wild - A New Adventure - Join Link in a massive, open-air adventure across the wilds of Hyrule in The Legend of Zelda: Breath of the Wild. With innovative gameplay that encourages exploration and experimentation, this installment redefines the boundaries of the beloved franchise.",
        "imageURL": "https://fs-prod-cdn.nintendo-europe.com/media/images/10_share_images/games_15/wiiu_14/SI_WiiU_TheLegendOfZeldaBreathOfTheWild_image1600w.jpg",
        "publisher": "Nintendo",
        "releaseDate": "2017-03-03",
        "news": {
            "title": "Breath of the Wild Redefines Zelda Series",
            "author": "HyruleAdventurer",
            "imageURL": "https://fs-prod-cdn.nintendo-europe.com/media/images/10_share_images/games_15/wiiu_14/SI_WiiU_TheLegendOfZeldaBreathOfTheWild_image1600w.jpg",
            "pages": [
                "Legend of Zelda: Breath of the Wild - A New Adventure - Join Link in a massive, open-air adventure across the wilds of Hyrule in The Legend of Zelda: Breath of the Wild. With innovative gameplay that encourages exploration and experimentation, this installment redefines the boundaries of the beloved franchise.",
                "Legend of Zelda: Breath of the Wild has redefined the Zelda series with its open-world exploration.",
                "The game encourages curiosity and experimentation, with a world full of puzzles, enemies, and secrets.",
                "Breath of the Wild is a testament to Nintendo`s ability to innovate and keep a long-running series fresh."
            ]
        }
    },
    {
        "gameID": 6,
        "title": "God of War: Norse Mythology Comes Alive",
        "genre": "Action-Adventure",
        "developer": "Santa Monica Studio",
        "description":"God of War: Norse Mythology Comes Alive - Embark on a mythological journey through the Norse realms with Kratos in God of War. This reimagined epic combines brutal combat, breathtaking visuals, and a gripping narrative, exploring themes of fatherhood and redemption.",
        "imageURL": "https://writinguntilragnarokhome.files.wordpress.com/2023/01/god-of-war-ragnarok-sales.jpg?w=1024",
        "publisher": "Sony Interactive Entertainment",
        "releaseDate": "2018-04-20",
        "news": {
            "title": "God of War Wins Game of The Year",
            "author": "KratosFan",
            "imageURL": "https://writinguntilragnarokhome.files.wordpress.com/2023/01/god-of-war-ragnarok-sales.jpg?w=1024",
            "pages": [
                "God of War: Norse Mythology Comes Alive - Embark on a mythological journey through the Norse realms with Kratos in God of War. This reimagined epic combines brutal combat, breathtaking visuals, and a gripping narrative, exploring themes of fatherhood and redemption.",
                "God of War has been crowned Game of the Year, thanks to its compelling storytelling and breathtaking visuals.",
                "Exploring Norse mythology, the game provides a fresh narrative to the series, focusing on the relationship between Kratos and his son, Atreus.",
                "Santa Monica Studio has masterfully crafted a world that feels alive and teeming with mysteries."
            ]
        }
    },
    {
        "gameID": 7,
        "title": "Dark Souls III: The Fire Fades",
        "genre": "Action-RPG",
        "developer": "FromSoftware",
        "description":"Dark Souls III: The Fire Fades - Confront the relentless challenge of Dark Souls III, where the fire fades and the world falls into ruin. This unforgiving, atmospheric action RPG is known for its intricate world design, deep lore, and intense, strategic combat.",
        
        "imageURL": "https://getwallpapers.com/wallpaper/full/8/5/c/925051-free-download-dark-souls-iii-wallpapers-1920x1080.jpg",
        "publisher": "Bandai Namco Entertainment",
        "releaseDate": "2016-04-12",
        "news": {
            "title": "Dark Souls III: The Ultimate Challenge",
            "author": "SoulsBorne",
            "imageURL": "https://getwallpapers.com/wallpaper/full/8/5/c/925051-free-download-dark-souls-iii-wallpapers-1920x1080.jpg",
            "pages": [
                "Dark Souls III: The Fire Fades - Confront the relentless challenge of Dark Souls III, where the fire fades and the world falls into ruin. This unforgiving, atmospheric action RPG is known for its intricate world design, deep lore, and intense, strategic combat.",
                "Dark Souls III continues to challenge players with its brutal difficulty and intricate world design.",
                "The game is a fitting conclusion to the series, offering the most refined gameplay and the most expansive world to explore.",
                "FromSoftware`s dedication to creating rewarding experiences for those who persevere is evident in every aspect of the game."
            ]
        }
    },
    {
        "gameID": 8,
        "title": "Monster Hunter: World - A New Frontier",
        "genre": "Action-RPG",
        "developer": "Capcom",
        "description":"Monster Hunter: World - A New Frontier - Step into the boots of a hunter venturing into a newly discovered continent in Monster Hunter: World. This action RPG enhances the series with expansive environments, seamless gameplay, and cooperative monster-hunting adventures.",
        
        "imageURL": "https://i.ytimg.com/vi/AzplEyeMdzc/maxresdefault.jpg",
        "publisher": "Capcom",
        "releaseDate": "2018-01-26",
        "news": {
            "title": "Monster Hunter: World Brings Hunters Together",
            "author": "HunterGuild",
            "imageURL": "https://i.ytimg.com/vi/AzplEyeMdzc/maxresdefault.jpg",
            "pages": [
                "Monster Hunter: World - A New Frontier - Step into the boots of a hunter venturing into a newly discovered continent in Monster Hunter: World. This action RPG enhances the series with expansive environments, seamless gameplay, and cooperative monster-hunting adventures.",
                "Monster Hunter: World has successfully brought the Monster Hunter series to a broader audience with its accessible gameplay and online features.",
                "The game offers a vast world filled with formidable monsters and rich ecosystems.",
                "Capcom`s continuous updates and expansions have kept the community engaged and the game fresh."
            ]
        }
    },
    {
        "gameID": 9,
        "title": "Persona 5: Steal Your Heart",
        "genre": "JRPG",
        "developer": "Atlus",
        "description": "Persona 5: Steal Your Heart - Immerse yourself in the stylish world of Persona 5, where a group of high school students lead double lives as Phantom Thieves. This unique RPG combines traditional turn-based combat with life simulation elements, wrapped in a visually stunning aesthetic.",
        
        "imageURL": "https://getwallpapers.com/wallpaper/full/a/e/8/68698.jpg",
        "publisher": "Atlus",
        "releaseDate": "2017-04-04",
        "news": {
            "title": "Persona 5: A Stylish JRPG Masterpiece",
            "author": "PhantomThief",
            "imageURL": "https://getwallpapers.com/wallpaper/full/a/e/8/68698.jpg",
            "pages": [
                "Persona 5: Steal Your Heart - Immerse yourself in the stylish world of Persona 5, where a group of high school students lead double lives as Phantom Thieves. This unique RPG combines traditional turn-based combat with life simulation elements, wrapped in a visually stunning aesthetic.",
                "Persona 5 is not just a game, it`s a journey into the world of high schoolers with extraordinary abilities.",
                "With its unique blend of JRPG elements, dungeon crawling, and life simulation, the game delivers an unforgettable experience.",
                "The art style, music, and story of Persona 5 have been praised universally, setting a new standard for the genre."
            ]
        }
    },
    {
        "gameID": 10,
        "title": "Final Fantasy XV: A Road Trip to Remember",
        "genre": "Action-RPG",
        "developer": "Square Enix",
        "description":"Final Fantasy XV: A Road Trip to Remember - Join Prince Noctis and his closest friends on an epic road trip across the fantastical world of Eos in Final Fantasy XV. This adventure blends action-packed combat, emotional storytelling, and a bond of friendship that transcends their mission.",
        "imageURL": "https://www.gamegrin.com/assets/games/final-fantasy-xv/_resampled/croppedimage1201631-final-fantasy-xv-header.jpg",
        "publisher": "Square Enix",
        "releaseDate": "2016-11-29",
        "news": {
            "title": "Final Fantasy XV: A Tale of Brotherhood",
            "author": "NoctisLucisCaelum",
            "imageURL": "https://www.gamegrin.com/assets/games/final-fantasy-xv/_resampled/croppedimage1201631-final-fantasy-xv-header.jpg",
            "pages": [
                "Final Fantasy XV: A Road Trip to Remember - Join Prince Noctis and his closest friends on an epic road trip across the fantastical world of Eos in Final Fantasy XV. This adventure blends action-packed combat, emotional storytelling, and a bond of friendship that transcends their mission.",
                "Final Fantasy XV breaks new ground for the series with its open world and real-time combat system.",
                "The story of Prince Noctis and his friends on a journey across the land of Eos is both epic and personal.",
                "Square Enix`s commitment to expanding the game with DLCs and updates has enriched the narrative and gameplay."
            ]
        }
    }
]';

$gameData = json_decode($games_json, true);

foreach ($gameData as $games) {
    if ($games['gameID'] == $id) {
        echo json_encode($games);
        break;
    }
}

?>