<?php
header('Content-Type: application/json');

$host = "localhost";
$dbname = "anmp_uts";
$user = "root";
$pass = "";

// Create a connection to the database
$conn = new mysqli($host, $user, $pass, $dbname);

// Check the connection
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Check if required fields are present
if (!isset($_POST['username']) || !isset($_POST['firstName']) || !isset($_POST['lastName'])) {
    echo json_encode(['status' => 'error', 'message' => 'Username, first name, and last name are required']);
    exit;
}

// Get data from POST array
$username = $_POST['username'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$password = isset($_POST['password']) ? $_POST['password'] : null;

// Check if a new password has been provided
if (!empty($password)) {
    $password = password_hash($password, PASSWORD_DEFAULT);
    $query = $conn->prepare("UPDATE users SET FirstName = ?, LastName = ?, password = ? WHERE username = ?");
    $query->bind_param("ssss", $firstName, $lastName, $password, $username);
} else {
    $query = $conn->prepare("UPDATE users SET FirstName = ?, LastName = ? WHERE username = ?");
    $query->bind_param("sss", $firstName, $lastName, $username);
}

// Execute the query
$result = $query->execute();

// Check the result of the query execution
if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'User updated successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $query->error]);
}

// Close the statement and the connection
$query->close();
$conn->close();
?>
